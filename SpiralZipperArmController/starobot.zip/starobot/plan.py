#!/usr/bin/env python
import trajectory
theta = 70
phi = 90
trajectory.traject(theta,phi)
