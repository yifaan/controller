#!/usr/bin/env python
'''
Set up and control spirabot using a joystick

To run this code via terminal:
>>ipython
>>cd pyckbot/starobot
>> execfile('star.py')
'''

import ckbot.logical as L # CKBot interface
# Import pygame, which handles joysticks and other inputs
import serial
import string
import pygame
from pygame import joystick
from pygame import event
from pygame.locals import *
from time import time as now, sleep

# Specify module ID and the name we want to give each of them:
#modules = { 42: 'Left', 16: 'Right'  } 
modules = { 07: 'Left', 17: 'Right', 42: 'Center',} 

if __name__=="__main__":

    import sys

    print "Initializing Spirabot Demo"  
    # Initialize pygame and a joystick
    pygame.init()
    joystick.init()
    print joystick.get_count()
    joystick.Joystick(0).init()
    #spicify serial port for Arduino
    #ser = serial.Serial('/dev/ttyACM0')
    if len(sys.argv) == 3:
        modules = { int(sys.argv[1]) : 'Left', int(sys.argv[2]) : 'Right' }
	

    # Create a CKBot cluster
    c = L.Cluster()
    c.populate( len(modules), modules )

    # Limit module speed and torque for safety
    for m in c.itermodules():
        m.set_torque_limit( .99 )
        # If module is a servo, then also limit speed
        if not m.get_mode():
            m.set_speed( 30 )

    print "STARobot initialized"
    drivable = False
    drive = 0.0
    centerDrive = 0.0
    turn = 0.0
    driveGain = 0.2
    turnGain = 0.2
    last_report = now()
    report_interval = 10
    degree = 0.0
    while True:
        try:
            # A 5 cell lipo shouldn't be used below 16 V.
            # Check to make sure the voltage is still good.
            if now()-last_report > report_interval:
                batt_v = c.at.Left.get_voltage()
                last_report = now()
                if batt_v < 10: # EDIT: set below 16 if using wired power
                    print 'Battery voltage less than 16V, please charge battery. Shutting off robot.'
                    break
                else:
                    print 'Battery voltage: %2.2f V' % batt_v
            # Get and handle events
            for evt in event.get():
                if evt.type == JOYAXISMOTION:   
                    # Look at joystick events and control values
                    if evt.axis == 4:
                        turn = evt.value
                        print "Horizontal Movement: %f" % turn
                    elif evt.axis == 3:
                        drive = evt.value
                        print "Vertical Movement: %f" % drive
		    elif evt.axis == 1:
                        centerDrive = evt.value
                        print "Center Movement: %f" % centerDrive
                elif evt.type == JOYBUTTONDOWN:
	            # Pressing 'RB' button on Joystick toggles drivability
                     if evt.button == 5:
                        drivable = not drivable
                        print 'Drivability status: %s' % str(drivable)
                    # Pressing the 'Left trigger' button to rotate left by 10 degrees
                    # elif evt.button == 6:
			#print 'Gripper rotates Left'
			#ser.write('3')
                    # Pressing the 'Right trigger' button to rotate right by 10 degrees
                    # elif evt.button == 7:
			#print 'Gripper rotates Right'
			#ser.write('4')
                    # Pressing the 'A' button to close the gripper
		    # elif evt.button == 1:
			#print 'Gripper closed'
			#ser.write('1')
                    # Pressing the 'B' button to open the gripper
                     elif evt.button == 2:
			print 'Gripper open'
			#ser.write('2')
                     elif evt.button == 0:
			print 'Gripper close gradually'
			#ser.write('6')
                     elif evt.button == 3:
			print 'Gripper open gradually'
			#ser.write('5')
		     elif evt.button == 4:
                        raise KeyboardInterrupt
            if drivable:
                # Set the torque values on the CR modules based on the 
                # inputs that we got from the joystick 
                c.at.Left.set_torque( -(drive*driveGain - turn*turnGain) )
                c.at.Right.set_torque(  drive*driveGain + turn*turnGain )
		c.at.Center.set_torque( centerDrive*.95)
		Lencoder = c.at.Left.get_pos()
       	        Rencoder = c.at.Right.get_pos()
	    else:
		c.at.Left.set_torque( 0 )
                c.at.Right.set_torque(  0 )
		c.at.Center.set_torque( 0)
		
        except KeyboardInterrupt:
            # Break out of the loop
            break

    print "Demo exiting, turning off all modules"
    # Turn the modules off before we exit for safety
    for m in c.itermodules():
        m.go_slack()
